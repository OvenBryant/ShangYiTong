package cn.bmob.sdkdemo.activity.relevance;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import cn.bmob.sdkdemo.R;

/**
 * Created on 2018/12/5 14:48
 *
 * @author zhangchaozhou
 */
public class PublishPostActivity extends AppCompatActivity {


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_publish_post);
    }
}
