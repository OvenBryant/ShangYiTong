package cn.bmob.sdkdemo.activity.object;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import cn.bmob.sdkdemo.R;

/**
 * Created on 2018/11/23 17:01
 *
 * @author zhangchaozhou
 */
public class QuerySubActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_query_sub);
    }
}
